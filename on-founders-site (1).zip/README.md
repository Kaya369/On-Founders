# On Founders

A working theory of what a great founder is, drawn from two hundred and fifty biographies.

## Deploy to Vercel

This is a static single-page site. Three ways to deploy, easiest first.

### Option 1: Drag and drop (fastest, 30 seconds)
1. Go to [vercel.com/new](https://vercel.com/new)
2. Drag this entire folder into the upload area
3. Click Deploy
4. Vercel gives you a live URL

### Option 2: Vercel CLI
```bash
npm i -g vercel
cd on-founders-site
vercel
```
Follow the prompts. Accept the defaults. Done.

### Option 3: GitHub + Vercel
1. Create a new repository on GitHub, push these files
2. Go to [vercel.com/new](https://vercel.com/new)
3. Import the repository
4. Click Deploy

## Custom domain

After deployment, in the Vercel dashboard: Project Settings → Domains → Add. Point your DNS to Vercel's nameservers, or add a CNAME record. Vercel issues the SSL certificate automatically.

## Editing

Everything lives in `index.html`. CSS is embedded at the top. Content is in the body. To edit, open the file, make changes, and redeploy (or Vercel auto-redeploys on git push if connected to GitHub).

## Files

- `index.html` — the entire site
- `vercel.json` — minor config (clean URLs, no-cache for HTML)
- `README.md` — this file

## Fonts

The site uses Fraunces (display) and EB Garamond (body), loaded from Google Fonts. No build step required.
